import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.interpolate import lagrange
#definir la funcion
def f(x):
    return 10*(1-np.exp(-0.8*x)*(np.cos(2.5*x + np.sin(2.5*x))))
x_interp = np.linspace(0, 6, 12)
y_interp = f(x_interp)
# Crear el modelo de interpolación
interpolator = interp1d(x_interp, y_interp, kind='cubic')
# Generar 200 puntos para evaluar el MSE
x_eval = np.linspace(0, 6, 200)
y_eval_real = f(x_eval)
y_eval_interp = interpolator(x_eval)
# Calcular el MSE
mse = np.mean((y_eval_real - y_eval_interp) ** 2)
print("MSE:", mse)
# Graficar la función original y la interpolación
plt.figure(figsize=(10, 6))
plt.plot(x_eval, y_eval_real, label='Función Original', color='blue')
plt.plot(x_eval, y_eval_interp, label='Interpolacion', color='orange', linestyle='--')
plt.scatter(x_interp, y_interp, color='red', label='Puntos de Interpolacion')
plt.title('Interpolacion Cubica')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.show()

#puntos de interpolacion
print("Puntos de Interpolacion:")
for x, y in zip(x_interp, y_interp):
    print(f"x: {x:.2f}, f(x): {y:.2f}")
    
#error maximo
max_error = np.max(np.abs(y_eval_real - y_eval_interp))
print("Error Maximo:", max_error)
#mostrar error maximo en la grafica
plt.figure(figsize=(10, 6))
plt.plot(x_eval, np.abs(y_eval_real - y_eval_interp), label='Error Absoluto', color='red')
plt.title('Error Absoluto entre la Funcion Original y la Interpolacion')

#comparar con lagrange grado 11 mediante grafica
lagrange_interpolator = lagrange(x_interp, y_interp)
y_eval_lagrange = lagrange_interpolator(x_eval)
plt.figure(figsize=(10, 6))
plt.plot(x_eval, y_eval_real, label='Función Original', color='blue')
plt.plot(x_eval, y_eval_interp, label='Interpolacion Cubica', color='orange', linestyle='--')
plt.plot(x_eval, y_eval_lagrange, label='Interpolacion de Lagrange', color='green', linestyle='-.')
plt.scatter(x_interp, y_interp, color='red', label='Puntos de Interpolacion')
plt.title('Comparacion de Interpolaciones')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.show()

#imprimir error maximo de lagrange y mostar en consola
max_error_lagrange = np.max(np.abs(y_eval_real - y_eval_lagrange))
print("Error Maximo de Lagrange:", max_error_lagrange)



